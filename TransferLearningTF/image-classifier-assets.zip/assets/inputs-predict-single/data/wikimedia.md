MichalPL, [Ok Toaster](https://commons.wikimedia.org/wiki/File:OK._Toaster.jpg) [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.en)  
